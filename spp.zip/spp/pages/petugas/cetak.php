<?php
ob_start();
include "../../conf/conn.php";
require_once("../../plugins/dompdf/autoload.inc.php");

use Dompdf\Dompdf;
$dompdf = new Dompdf();
$id = isset($_GET['id_petugas']) ? mysqli_real_escape_string($koneksi, $_GET['id_petugas']) : '';

// Periksa apakah ID buku valid
if (!empty($id)) {
    $query = mysqli_query($koneksi, "SELECT * FROM petugas WHERE id_petugas='$id'");

    // Periksa apakah kueri berhasil dieksekusi
    if ($query) {
        $html = '<center><h3>Daftar Nama Petugas</h3></center><hr/><br/>';
        $html .= '<table border="1" width="100%">
        <tr><th>No</th><th>Id Petugas</th><th>Username</th><th>password</th><th>Nama Petugas</th><thLevel</th></tr>';
        $no = 1;
        while ($row = mysqli_fetch_array($query)) {
            $html .= "<tr><td>" . $no . "</td><td>" . $row['id_petugas'] . "</td><td>" . $row['username'] . "</td><td>" . $row['password'] . "</td><td>" . $row['nama_petugas'] . "</td><td>" . $row['level'] . "</td></tr>";
            $no++;
        }

        $html .= "</table>";
        $dompdf->loadHtml($html);
        // Setting ukuran dan orientasi kertas
        $dompdf->setPaper('A4', 'portrait');
        // Rendering dari HTML Ke PDF
        $dompdf->render();
        // Melakukan output file Pdf
        $dompdf->stream('laporan_Petugas.pdf');
    } else {
        // Kueri tidak berhasil dieksekusi
        echo "Terjadi kesalahan dalam mengambil data Petugas.";
    }
} else {
    // ID buku tidak valid atau tidak ada
    echo "ID Petugas tidak valid atau tidak ada.";
}
?>