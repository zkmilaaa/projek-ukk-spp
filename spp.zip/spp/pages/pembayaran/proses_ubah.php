<?php
include "../../conf/conn.php";
if($_POST)
{
    $id_petugas    = $_SESSION['id_petugas'];
    $nisn          = $_POST['nisn'];
    $tgl_bayar     = $_POST['tgl_bayar'];
    $bulan_dibayar = $_POST['bulan_dibayar'];
    $tahun_dibayar = $_POST['tahun_dibayar'];
    $nama = $_POST['nama'];
    $id_spp        = $_POST['id_spp'];
    $jumlah_bayar  = $_POST['jumlah_bayar'];

    $query = ("UPDATE pembayaran SET nisn='$nisn',tgl_bayar='$tgl_bayar',Bulan_dibayar='$bulan_dibayar',tahun_dibayar='$tahun_dibayar',nama='$nama',id_spp='$id_spp',jumlah_bayar='$jumlah_bayar' WHERE id_petugas ='$id_petugas'");
    if(!mysqli_query($koneksi, "$query")){
    die(mysqli_error($koneksi));
                } else {
                    echo '<script>alert("Data Berhasil Diubah !!!");
                    window.location.href="../../index.php?page=data_pembayar"</script>';
                }
            }
    
          ?>